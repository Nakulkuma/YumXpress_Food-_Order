
package in.scalive.gui.awt;

import java.awt.Frame;

public class Example1 {
    public static void main(String [] args)
    {
        Frame fr=new Frame();
        fr.setSize(400,400);
        fr.setVisible(true);
    }
}
