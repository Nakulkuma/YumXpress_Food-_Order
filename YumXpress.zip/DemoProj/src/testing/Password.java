/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testing;

import java.util.Base64;

/**
 *
 * @author HP
 */
public class Password {
    public static void main(String [] args)
    {
        String pwd="admin";
        Base64.Encoder en=Base64.getEncoder();
        String encryptedPwd=en.encodeToString(pwd.getBytes());
        System.out.println("Original pwd: "+pwd);
        System.out.println("Encrypted pwd: "+encryptedPwd);
        
        Base64.Decoder dec=Base64.getDecoder();
        byte[]arr=dec.decode(encryptedPwd.getBytes());
        String decPwd=new String(arr);
        System.out.println("Decrypted pwd: "+decPwd);
    }
}
