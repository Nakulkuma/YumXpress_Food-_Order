/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package yumxpress.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import yumxpress.dbutil.DBConnection;
import yumxpress.pojo.CompanyPojo;

/**
 *
 * @author HP
 */
public class CompanyDAO {
    public static String getNewId()throws SQLException
    {
        Connection conn=DBConnection.getConnection();
        Statement st=conn.createStatement();
        ResultSet rs=st.executeQuery("Select max(company_id) from companies");
        rs.next();
        String id=rs.getString(1);
        String compId="";
        if(id!=null)
        {
            id=id.substring(4);
            compId="CMP-"+(Integer.parseInt(id)+1);
        }else
        {
         compId="CMP-101";   
        }
        return compId;
    }
    
    public static boolean addSeller(CompanyPojo comp) throws SQLException
    {
        Connection conn=DBConnection.getConnection();
        PreparedStatement ps=conn.prepareStatement("insert into companies values(?,?,?,?,?,?,?");
        
        ps.setString(1, getNewId());
        ps.setString(2, comp.getCompanyName());
        ps.setString(3, comp.getOwnerName());
        ps.setString(4, comp.getPassword());
        ps.setString(5, "ACTIVE");
        ps.setString(6, comp.getEmailId());
        ps.setString(7, comp.getSecurityKey());
        
        return ps.executeUpdate()==1;
    }
   
}
